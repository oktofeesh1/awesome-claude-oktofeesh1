# HeyClaude Category Notes

- agents: agent workflows, subagents, assistants, or agentic task definitions.
- mcp: Model Context Protocol servers, configs, or MCP packages.
- tools: user-facing tools, CLIs, extensions, validators, or apps.
- skills: Agent Skill packages centered on SKILL.md.
- rules: Cursor rules, AGENTS guidance, or reusable instruction rules.
- commands: slash commands or command templates.
- hooks: automation hooks or lifecycle scripts.
- guides: practical how-to guides with durable source value.
- collections: curated bundles with a real shared workflow.
- statuslines: statusline configs or prompt/status display assets.

When category fit is unclear, state the ambiguity and recommend the category that matches the installation or usage surface.
